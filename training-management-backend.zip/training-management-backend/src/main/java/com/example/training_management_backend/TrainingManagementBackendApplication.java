package com.example.training_management_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TrainingManagementBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(TrainingManagementBackendApplication.class, args);
	}

}
